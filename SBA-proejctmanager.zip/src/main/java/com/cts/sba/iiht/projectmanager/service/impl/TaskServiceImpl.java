package com.cts.sba.iiht.projectmanager.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.sba.iiht.projectmanager.entity.Task;
import com.cts.sba.iiht.projectmanager.repository.ITaskRepository;
import com.cts.sba.iiht.projectmanager.service.ITaskService;

// TODO: Auto-generated Javadoc
/**
 * The Class TaskServiceImpl.
 */
@Service
public class TaskServiceImpl implements ITaskService {

	/** The task repo. */
	@Autowired
	ITaskRepository taskRepo;
	
	/**
	 * Find task.
	 *
	 * @param id the id
	 * @return the task
	 */
	@Override
	public Task findTask(Long id) {
		Optional<Task> task = taskRepo.findById(id);
		return task.isPresent() ? task.get() : null;
	}
	
	/**
	 * Find all tasks.
	 *
	 * @return the list
	 */
	@Override
	public List<Task> findAllTasks() {
		return taskRepo.findAll();
	}

	/**
	 * Adds the task.
	 *
	 * @param task the task
	 * @return the task
	 */
	@Transactional
	@Override
	public Task addTask(Task task) {
		Task taskReturned = taskRepo.save(task);
		return taskReturned;
	}

	/**
	 * Update task.
	 *
	 * @param task the task
	 * @return the task
	 */
	@Transactional
	@Override
	public Task updateTask(Task task) {
		return taskRepo.save(task);

	}

	/**
	 * Delete task.
	 *
	 * @param taskId the task id
	 */
	@Transactional	
	@Override
	public void deleteTask(Long taskId) {
		taskRepo.deleteById(taskId);

	}

	/**
	 * End task.
	 *
	 * @param taskId the task id
	 * @return the task
	 */
	@Transactional
	@Override
	public Task endTask(Long taskId) {
		Optional<Task> taskOpt = taskRepo.findById(taskId);
		if (taskOpt.isPresent()) {
			Task task = taskOpt.get();
			task.setEndDate(new Date());
			return taskRepo.save(task);
		}
		
		return null;
	}

}
