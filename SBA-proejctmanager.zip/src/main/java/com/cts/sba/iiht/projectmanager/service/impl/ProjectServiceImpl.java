package com.cts.sba.iiht.projectmanager.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.sba.iiht.projectmanager.entity.Project;
import com.cts.sba.iiht.projectmanager.entity.Task;
import com.cts.sba.iiht.projectmanager.repository.IProjectRepository;
import com.cts.sba.iiht.projectmanager.service.IProjectService;

// TODO: Auto-generated Javadoc
/**
 * The Class ProjectServiceImpl.
 */
@Service
public class ProjectServiceImpl implements IProjectService {

	/** The project repo. */
	@Autowired
	IProjectRepository projectRepo;
	
	/**
	 * Find all projects.
	 *
	 * @return the list
	 */
	@Override
	public List<Project> findAllProjects() {
		return projectRepo.findAll();
	}

	/**
	 * Task completed.
	 *
	 * @return the predicate
	 */
	private static Predicate<Task> taskCompleted() {
		return task -> task.getEndDate().before(new Date());
	}
	
	/**
	 * Find all projects with task.
	 *
	 * @return the list
	 */
	@Override
	public List<Project> findAllProjectsWithTask() {
		List<Project> projects = new ArrayList<>();
		 
		 projectRepo.findAll().stream().forEach(p -> {
			 Project project = new Project(p.getProjectId(), p.getProjectName(), 
					 					   p.getStartDate(), p.getEndDate(), 
					 					   p.getPriority(),p.getUser());
			 
			 project.setCountOfTasks(!p.getTasks().isEmpty()?p.getTasks().size():0);
			 project.setCountOfCompletedTasks((int) p.getTasks().stream().filter(taskCompleted()).count());							 
			 projects.add(project);
		 });
		 
		 return projects;
	}

	/**
	 * Find project by id.
	 *
	 * @param projectId the project id
	 * @return the project
	 */
	@Override
	public Project findProjectById(Long projectId) {
		Optional<Project> optProject = projectRepo.findById(projectId);
		Project project = optProject.isPresent() ? optProject.get() : null;

		return project;
	}

	/**
	 * Adds the project.
	 *
	 * @param project the project
	 * @return the project
	 */
	@Transactional
	@Override
	public Project addProject(Project project) {
		Project projectReturned = projectRepo.save(project);
		return projectReturned;

	}

	/**
	 * Update project.
	 *
	 * @param project the project
	 * @return the project
	 */
	@Transactional
	@Override
	public Project updateProject(Project project) {
		return addProject(project);
	}

	/**
	 * End project.
	 *
	 * @param projectId the project id
	 */
	@Transactional
	@Override
	public void endProject(Long projectId) {
		Optional<Project> optProject = projectRepo.findById(projectId);
		if (optProject.isPresent()) {
			Project project = optProject.get();
			project.getTasks().forEach(t -> t.setEndDate(project.getEndDate()));
			projectRepo.save(project);
		}
		
		
	}
	
	
	/**
	 * Delete project.
	 *
	 * @param projectId the project id
	 */
	@Transactional
	@Override
	public void deleteProject(Long projectId) {
		projectRepo.deleteById(projectId);

	}

}
