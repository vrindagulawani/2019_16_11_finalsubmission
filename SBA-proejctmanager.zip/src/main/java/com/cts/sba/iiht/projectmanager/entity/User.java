/**

 *

 */

package com.cts.sba.iiht.projectmanager.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;


// TODO: Auto-generated Javadoc
/**
 * The Class User.
 */
@Entity
@Table(name = "User_DB_TBL")
public class User implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The user id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "userId", updatable = false, nullable = false)
	private long userId;

	/** The first name. */
	@Size(max = 100)
	private String firstName;

	/** The last name. */
	@Size(max = 100)
	private String lastName;

	/** The employee id. */
	@Digits(integer = 9, fraction = 0)
	private long employeeId;

	/** The projects. */
	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
	private Set<Project> projects = new HashSet<>();
	
	/** The tasks. */
	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
	private Set<Task> tasks = new HashSet<>();

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public long getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId the new user id
	 */
	public void setUserId(long userId) {
		this.userId = userId;
	}

	/**
	 * Gets the first name.
	 *
	 * @return the first name
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the first name.
	 *
	 * @param firstName the new first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the last name
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Sets the last name.
	 *
	 * @param lastName the new last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Gets the employee id.
	 *
	 * @return the employee id
	 */
	public long getEmployeeId() {
		return employeeId;
	}

	/**
	 * Sets the employee id.
	 *
	 * @param employeeId the new employee id
	 */
	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * Instantiates a new user.
	 *
	 * @param firstName the first name
	 * @param lastName the last name
	 * @param employeeId the employee id
	 */
	public User(String firstName, String lastName, long employeeId) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.employeeId = employeeId;
	}

	/**
	 * Instantiates a new user.
	 */
	public User() {
		super();
	}

}
