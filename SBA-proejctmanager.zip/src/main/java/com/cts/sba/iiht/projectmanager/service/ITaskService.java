package com.cts.sba.iiht.projectmanager.service;

import java.util.List;

import com.cts.sba.iiht.projectmanager.entity.Task;

// TODO: Auto-generated Javadoc
/**
 * The Interface ITaskService.
 */
public interface ITaskService {

	/**
	 * Find all tasks.
	 *
	 * @return the list
	 */
	public List<Task> findAllTasks();
	
	/**
	 * Adds the task.
	 *
	 * @param task the task
	 * @return the task
	 */
	public Task addTask(Task task);
	
	/**
	 * Update task.
	 *
	 * @param task the task
	 * @return the task
	 */
	public Task updateTask(Task task);
	
	/**
	 * Delete task.
	 *
	 * @param taskId the task id
	 */
	public void deleteTask(Long taskId);
	
	/**
	 * End task.
	 *
	 * @param taskId the task id
	 * @return the task
	 */
	public Task endTask(Long taskId) ;
	
	/**
	 * Find task.
	 *
	 * @param taskId the task id
	 * @return the task
	 */
	public Task findTask(Long taskId);
}
