INSERT INTO `sbacogdb`.`user_db_tbl`
(
`user_id`,
`employee_id`,
`first_name`,
`last_name`)
VALUES
(1,
128731,
'F1',
'L1');

INSERT INTO `sbacogdb`.`user_db_tbl`
(`user_id`,
`employee_id`,
`first_name`,
`last_name`)
VALUES
(2,
128732,
'F2',
'L2');

INSERT INTO `sbacogdb`.`user_db_tbl`
(`user_id`,
`employee_id`,
`first_name`,
`last_name`)
VALUES
(3,
128733,
'F3',
'L3');

INSERT INTO `sbacogdb`.`user_db_tbl`
(`user_id`,
`employee_id`,
`first_name`,
`last_name`)
VALUES
(4,
128734,
'F4',
'L4');

INSERT INTO `sbacogdb`.`user_db_tbl`
(`user_id`,
`employee_id`,
`first_name`,
`last_name`)
VALUES
(5,
128735,
'F5',
'L5');

INSERT INTO `sbacogdb`.`project_db_tbl`
(`project_id`,
`end_date`,
`priority`,
`project_name`,
`start_date`,
`user_id`)
VALUES
(1,
CURDATE(),
10,
'P1',
CURDATE(),
1);

INSERT INTO `sbacogdb`.`project_db_tbl`
(`project_id`,
`end_date`,
`priority`,
`project_name`,
`start_date`,
`user_id`)
VALUES
(2,
CURDATE(),
10,
'P1',
CURDATE(),
1);

INSERT INTO `sbacogdb`.`project_db_tbl`
(`project_id`,
`end_date`,
`priority`,
`project_name`,
`start_date`,
`user_id`)
VALUES
(3,
CURDATE()+1,
10,
'P2',
CURDATE()+3,
2);

INSERT INTO `sbacogdb`.`project_db_tbl`
(`project_id`,
`end_date`,
`priority`,
`project_name`,
`start_date`,
`user_id`)
VALUES
(4,
CURDATE(),
20,
'P3',
CURDATE()+5,
2);

INSERT INTO `sbacogdb`.`project_db_tbl`
(`project_id`,
`end_date`,
`priority`,
`project_name`,
`start_date`,
`user_id`)
VALUES
(5,
CURDATE(),
15,
'P4',
CURDATE()+10,
3);

INSERT INTO `sbacogdb`.`parent_task_db_tbl`
(`parent_id`,
`parent_task`,
`project_id`)
VALUES
(1,
'PT1',
1);

INSERT INTO `sbacogdb`.`parent_task_db_tbl`
(`parent_id`,
`parent_task`,
`project_id`)
VALUES
(2,
'PT2',
2);

INSERT INTO `sbacogdb`.`parent_task_db_tbl`
(`parent_id`,
`parent_task`,
`project_id`)
VALUES
(3,
'PT3',
1);

INSERT INTO `sbacogdb`.`parent_task_db_tbl`
(`parent_id`,
`parent_task`,
`project_id`)
VALUES
(4,
'PT4',
2);

INSERT INTO `sbacogdb`.`parent_task_db_tbl`
(`parent_id`,
`parent_task`,
`project_id`)
VALUES
(5,
'PT5',
1);


INSERT INTO `sbacogdb`.`task_db_tbl`
(`task_id`,
`end_date`,
`priority`,
`start_date`,
`status`,
`task_name`,
`parent_id`,
`project_id`,
`user_id`)
VALUES
(1,
CURDATE()+5,
5,
CURDATE(),
'New',
'Task1',
1,
1,
1);

INSERT INTO `sbacogdb`.`task_db_tbl`
(`task_id`,
`end_date`,
`priority`,
`start_date`,
`status`,
`task_name`,
`parent_id`,
`project_id`,
`user_id`)
VALUES
(2,
CURDATE()+5,
5,
CURDATE(),
'New',
'Task2',
2,
1,
2);

INSERT INTO `sbacogdb`.`task_db_tbl`
(`task_id`,
`end_date`,
`priority`,
`start_date`,
`status`,
`task_name`,
`parent_id`,
`project_id`,
`user_id`)
VALUES
(3,
CURDATE()+5,
5,
CURDATE(),
'New',
'Task3',
1,
2,
2);

INSERT INTO `sbacogdb`.`task_db_tbl`
(`task_id`,
`end_date`,
`priority`,
`start_date`,
`status`,
`task_name`,
`parent_id`,
`project_id`,
`user_id`)
VALUES
(4,
CURDATE()+5,
5,
CURDATE(),
'New',
'Task4',
1,
1,
1);

INSERT INTO `sbacogdb`.`task_db_tbl`
(`task_id`,
`end_date`,
`priority`,
`start_date`,
`status`,
`task_name`,
`parent_id`,
`project_id`,
`user_id`)
VALUES
(5,
CURDATE()+5,
5,
CURDATE(),
'New',
'Task5',
1,
2,
1);


