export const environment = {
  production: true,
  apiUrl: 'http://localhost:9090'
};
