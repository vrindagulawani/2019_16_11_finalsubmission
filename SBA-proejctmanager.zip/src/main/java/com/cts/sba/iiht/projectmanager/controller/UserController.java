package com.cts.sba.iiht.projectmanager.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.sba.iiht.projectmanager.entity.User;
import com.cts.sba.iiht.projectmanager.service.IUserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

// TODO: Auto-generated Javadoc
/**
 * The Class UserController.
 */
@CrossOrigin
@RestController
@Api(value ="v1 "+ "User")
public class UserController {
	
	/** The service. */
	@Autowired
	IUserService service;
	
	/**
	 * Find all users.
	 *
	 * @return the list
	 */
	@RequestMapping(path="/users", method=RequestMethod.GET)
	@ApiOperation(value = "Get all Users")
	public List<User> findAllUsers(){
		return service.findAllUsers();
	}
	
	/**
	 * Find user.
	 *
	 * @param id the id
	 * @return the user
	 */
	@RequestMapping(path="/users/{id}", method=RequestMethod.GET)
	@ApiOperation(value = "Get User by id")
	public User findUser(@PathVariable Long id){
		return service.findUserById(id);
	}
	
	/*@RequestMapping(path="/users/projects/{id}", method=RequestMethod.GET)
	@ApiOperation(value = "Get User Projects by id")
	public User findUserByProjectId(@PathVariable Integer id){
		return service.findUserByProject(id);
	}
	
	@RequestMapping(path="/users/tasks/{id}", method=RequestMethod.GET)
	@ApiOperation(value = "Get User task by id")
	public User findUserByTaskId(@PathVariable Integer id){
		return service.findUserByTask(id);
	}*/
	
	/**
	 * Adds the user.
	 *
	 * @param user the user
	 */
	@ApiOperation(value = "Post user data")
	@RequestMapping(path="/users", method=RequestMethod.POST)
	public void addUser(@RequestBody User user) {
		 service.addUser(user);
	}
	
	/**
	 * Update user.
	 *
	 * @param user the user
	 */
	@ApiOperation(value = "Put user data")
	@RequestMapping(path="/users", method=RequestMethod.PUT)
	public void updateUser(@RequestBody User user){
		 service.updateUser(user);
	}
	
	/**
	 * Delete user.
	 *
	 * @param id the id
	 */
	@ApiOperation(value = "delete user by id")
	@RequestMapping(path="/users/{id}", method=RequestMethod.DELETE)
	public void deleteUser(@PathVariable Long id){
		 service.deleteUser(id);
	}
}
