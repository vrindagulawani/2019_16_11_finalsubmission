package com.cts.sba.iiht.projectmanager.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.sba.iiht.projectmanager.entity.ParentTask;
import com.cts.sba.iiht.projectmanager.repository.IParentTaskRepository;
import com.cts.sba.iiht.projectmanager.service.IParentTaskService;

// TODO: Auto-generated Javadoc
/**
 * The Class ParentTaskServiceImpl.
 */
@Service
public class ParentTaskServiceImpl implements IParentTaskService {

	
	/** The parent task repo. */
	@Autowired
	IParentTaskRepository parentTaskRepo;
	
	/**
	 * Adds the parent task.
	 *
	 * @param parentTask the parent task
	 * @return the parent task
	 */
	@Transactional
	@Override
	public ParentTask addParentTask(ParentTask parentTask) {
		ParentTask parentTaskReturned = parentTaskRepo.save(parentTask);
		return parentTaskReturned;

	}

	/**
	 * Find parent task by id.
	 *
	 * @param parentTaskId the parent task id
	 * @return the parent task
	 */
	@Override
	public ParentTask findParentTaskById(Long parentTaskId) {
		Optional<ParentTask> optParentTask = parentTaskRepo.findById(parentTaskId);
		ParentTask parentTask = optParentTask.isPresent() ? optParentTask.get() : null;
		return parentTask;
	}
	
	/**
	 * Find all parent tasks.
	 *
	 * @return the list
	 */
	@Override
	public List<ParentTask> findAllParentTasks() {
		return parentTaskRepo.findAll();
	}

	/**
	 * Delete Parent task
	 */
	@Transactional
	@Override
	public void deleteParentTask(Long id) {
		parentTaskRepo.deleteById(id);
		
	}

}
