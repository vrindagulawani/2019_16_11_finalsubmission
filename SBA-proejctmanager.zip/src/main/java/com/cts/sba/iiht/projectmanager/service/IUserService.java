package com.cts.sba.iiht.projectmanager.service;

import java.util.List;

import com.cts.sba.iiht.projectmanager.entity.User;

// TODO: Auto-generated Javadoc
/**
 * The Interface IUserService.
 */
public interface IUserService {
	
	/**
	 * Adds the user.
	 *
	 * @param user the user
	 * @return the user
	 */
	public User addUser(User user);

	/**
	 * Update user.
	 *
	 * @param user the user
	 * @return the user
	 */
	public User updateUser(User user);

	/**
	 * Delete user.
	 *
	 * @param userId the user id
	 */
	public void deleteUser(Long userId);
	
	/**
	 * Find user by id.
	 *
	 * @param userId the user id
	 * @return the user
	 */
	public User findUserById(Long userId);
	
	/**
	 * Find all users.
	 *
	 * @return the list
	 */
	public List<User> findAllUsers();

}
