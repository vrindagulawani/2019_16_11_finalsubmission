package com.cts.sba.iiht.projectmanager.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.sba.iiht.projectmanager.entity.Project;
import com.cts.sba.iiht.projectmanager.entity.Task;

// TODO: Auto-generated Javadoc
/**
 * The Interface ITaskRepository.
 */
@Repository
public interface ITaskRepository extends JpaRepository<Task, Long>{
	
	/** The Constant project_for_task. */
	public final static String project_for_task = "Select p.* From Project_DB_TBL p join Task_DB_TBL t on p.project_id = t.project_id where t.task_id = :taskId";

	/**
	 * Find project for task.
	 *
	 * @param taskId the task id
	 * @return the project
	 */
	@Query(value = project_for_task, nativeQuery = true)
	public Project findProjectForTask(@Param("taskId") Long taskId);

}
